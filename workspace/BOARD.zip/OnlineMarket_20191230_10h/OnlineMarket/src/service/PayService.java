package service;

public interface PayService {

	void insertpay();
	
	void payList();//�ֹ�����//null 12.24 

	void buying();//����//null 12.27 13:45

	void selectPay();
	
	void selectPayList();
	
	
	
}
