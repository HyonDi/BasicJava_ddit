package service;

public interface UserService {
	void join();		
	
	void login(); 		
	
	void userList();	
	
	void insertBoard();	//hh.joo 20191224 add

	void printBoard();	//hh.joo 20191224 add
	
	void printMyPage();
	
	
	
	
	
	
	
//	void addCategory();	//hh.joo 20191226 add 
//		
//	void printCategoryList();	//hh.joo 20191226 add
//	
//	void addToCart();	//hh.joo 20191226 add
//	
//	void printCartList();	//hh.joo 20191226 add
	
}
