package service;

//hh.joo 20191227 add
public interface CartService {

	void addToCart();			

	void printCartList();
}
